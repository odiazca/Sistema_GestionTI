<?php
class Controller
{
    protected function model(string $name)
    {
        require_once APP_PATH . "/models/{$name}.php";
        return new $name();
    }

    /** Renderiza una vista dentro del layout principal */
    protected function render(string $view, array $data = [], string $title = ''): void
    {
        extract($data);
        ob_start();
        require APP_PATH . "/views/{$view}.php";
        $content = ob_get_clean();
        $pageTitle = $title;
        $menu = require ROOT_PATH . '/config/menu.php';
        $badges = $this->badges();
        require APP_PATH . '/views/layouts/main.php';
    }

    /** Renderiza una vista sin layout (login) */
    protected function renderPlain(string $view, array $data = []): void
    {
        extract($data);
        require APP_PATH . "/views/{$view}.php";
    }

    protected function redirect(string $path): void
    {
        header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
        exit;
    }

    protected function requireAuth(): void
    {
        if (!Auth::check()) $this->redirect('login');
    }

    protected function json($data, int $code = 200): void
    {
        http_response_code($code);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE);
        exit;
    }

    private function badges(): array
    {
        try {
            $d = $this->model('Dashboard');
            return $d->badges();
        } catch (Throwable $e) { return []; }
    }
}
