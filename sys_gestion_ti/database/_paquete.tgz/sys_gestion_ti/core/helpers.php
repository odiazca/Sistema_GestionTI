<?php
function e($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function url(string $p = ''): string { return BASE_URL . '/' . ltrim($p, '/'); }
function asset(string $p): string { return BASE_URL . '/assets/' . ltrim($p, '/'); }
function iniciales(string $n): string {
    $p = preg_split('/\s+/', trim($n)); $i = mb_substr($p[0] ?? '', 0, 1);
    if (count($p) > 1) $i .= mb_substr(end($p), 0, 1);
    return mb_strtoupper($i);
}
function hace(string $fecha): string {
    $d = time() - strtotime($fecha);
    if ($d < 60) return 'ahora';
    if ($d < 3600) return 'hace ' . floor($d / 60) . ' min';
    if ($d < 86400) return 'hace ' . floor($d / 3600) . ' h';
    return 'hace ' . floor($d / 86400) . ' d';
}
