<?php
$u = Auth::user();
$actual = strtolower(explode('/', trim($_GET['url'] ?? 'dashboard', '/'))[0] ?: 'dashboard');
$hora = (int)date('G');
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($pageTitle) ?> · <?= APP_NAME ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= asset('css/app.css') ?>" rel="stylesheet">
<script>try{if(localStorage.getItem('td_theme')==='dark')document.documentElement.setAttribute('data-theme','dark');if(localStorage.getItem('td_collapsed')==='1')document.documentElement.classList.add('sb-collapsed');}catch(e){}</script>
</head>
<body class="app-body">

<div class="sb-backdrop" id="sbBackdrop"></div>

<!-- ============ SIDEBAR ============ -->
<aside class="sidebar" id="sidebar">
  <div class="sb-head">
    <a href="<?= url('dashboard') ?>" class="brand">
      <span class="brand-mark"><i class="bi bi-headset"></i></span>
      <span class="brand-text"><b><?= APP_NAME ?></b><small>Soporte TI</small></span>
    </a>
  </div>

  <nav class="sb-nav">
    <?php foreach ($menu as $seccion => $items): ?>
      <div class="sb-section"><?= e($seccion) ?></div>
      <?php foreach ($items as $it):
        $activo = $actual === $it['slug'];
        $badge = !empty($it['badge']) ? ($badges[$it['badge']] ?? 0) : 0; ?>
        <a href="<?= url($it['slug']) ?>" class="sb-link <?= $activo ? 'active' : '' ?>" title="<?= e($it['label']) ?>">
          <i class="bi <?= e($it['icon']) ?>"></i>
          <span class="sb-label"><?= e($it['label']) ?></span>
          <?php if ($badge): ?><span class="sb-badge <?= $it['badge'] === 'stock_bajo' ? 'warn' : '' ?>"><?= (int)$badge ?></span>
          <?php elseif (empty($it['ready'])): ?><span class="sb-soon">pronto</span><?php endif; ?>
        </a>
      <?php endforeach; ?>
    <?php endforeach; ?>
  </nav>

  <div class="sb-foot">
    <div class="sb-support">
      <div class="sb-support-ic"><i class="bi bi-lightning-charge-fill"></i></div>
      <div><b>Estado del servicio</b><small><span class="dot-live"></span> Todo operativo</small></div>
    </div>
  </div>
</aside>

<!-- ============ MAIN ============ -->
<div class="main-wrap">
  <header class="topbar">
    <button class="icon-btn" id="btnSidebar" aria-label="Menú"><i class="bi bi-list"></i></button>

    <div class="search-ui d-none d-md-flex">
      <i class="bi bi-search"></i>
      <input type="text" placeholder="Buscar tickets, clientes, equipos…" aria-label="Buscar">
      <kbd>Ctrl K</kbd>
    </div>

    <div class="ms-auto d-flex align-items-center gap-2">
      <a href="<?= url('tickets') ?>" class="btn btn-brand btn-sm d-none d-sm-inline-flex align-items-center gap-1"><i class="bi bi-plus-lg"></i> Nuevo ticket</a>

      <button class="icon-btn" id="btnTheme" aria-label="Tema"><i class="bi bi-moon-stars"></i></button>

      <div class="dropdown">
        <button class="icon-btn position-relative" data-bs-toggle="dropdown" aria-label="Notificaciones">
          <i class="bi bi-bell"></i><span class="notif-dot"></span>
        </button>
        <div class="dropdown-menu dropdown-menu-end dd-ui p-0" style="width:340px">
          <div class="dd-head">Notificaciones <span class="chip chip-soft ms-auto">3 nuevas</span></div>
          <a class="dd-item" href="#"><i class="bi bi-exclamation-triangle-fill text-danger"></i><div><b>Ticket crítico sin asignar</b><small>Alerta de temperatura en rack · hace 7 min</small></div></a>
          <a class="dd-item" href="#"><i class="bi bi-clock-history text-warning"></i><div><b>SLA próximo a vencer</b><small>TCK-01227 vence en 45 min</small></div></a>
          <a class="dd-item" href="#"><i class="bi bi-file-earmark-text text-primary"></i><div><b>Contrato por vencer</b><small>CT-2026-001 · 25 días</small></div></a>
          <a class="dd-foot" href="#">Ver todas las notificaciones</a>
        </div>
      </div>

      <div class="dropdown">
        <button class="user-btn" data-bs-toggle="dropdown">
          <span class="avatar" style="background:<?= e($u['color']) ?>"><?= e(iniciales($u['nombre'])) ?></span>
          <span class="d-none d-md-block text-start lh-sm"><b><?= e($u['nombres']) ?></b><small><?= e($u['rol']) ?></small></span>
          <i class="bi bi-chevron-down d-none d-md-block small text-muted"></i>
        </button>
        <div class="dropdown-menu dropdown-menu-end dd-ui p-0" style="width:240px">
          <div class="dd-user">
            <span class="avatar avatar-lg" style="background:<?= e($u['color']) ?>"><?= e(iniciales($u['nombre'])) ?></span>
            <div><b><?= e($u['nombre']) ?></b><small><?= e($u['email']) ?></small></div>
          </div>
          <a class="dd-link" href="#"><i class="bi bi-person"></i> Mi perfil</a>
          <a class="dd-link" href="<?= url('configuracion') ?>"><i class="bi bi-gear"></i> Configuración</a>
          <a class="dd-link text-danger" href="<?= url('logout') ?>"><i class="bi bi-box-arrow-right"></i> Cerrar sesión</a>
        </div>
      </div>
    </div>
  </header>

  <main class="content">
    <?= $content ?>
  </main>

  <footer class="app-footer">
    <span>© <?= date('Y') ?> <?= APP_NAME ?> · <?= APP_SUBTITLE ?></span>
    <span>v<?= APP_VERSION ?></span>
  </footer>
</div>

<?php $flashes = $_SESSION['flash'] ?? []; unset($_SESSION['flash']); ?>
<div class="toast-stack">
  <?php foreach ($flashes as $f): $ic = ['success'=>'bi-check-circle-fill','danger'=>'bi-exclamation-octagon-fill','warning'=>'bi-exclamation-triangle-fill','info'=>'bi-info-circle-fill'][$f['type']] ?? 'bi-info-circle-fill'; ?>
  <div class="toast-ui toast-<?= e($f['type']) ?>" role="alert"><i class="bi <?= $ic ?>"></i><span><?= e($f['msg']) ?></span><button type="button" onclick="this.parentNode.remove()">&times;</button></div>
  <?php endforeach; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script src="<?= asset('js/app.js') ?>"></script>
<?php if (isset($scripts)) echo $scripts; ?>
</body>
</html>
