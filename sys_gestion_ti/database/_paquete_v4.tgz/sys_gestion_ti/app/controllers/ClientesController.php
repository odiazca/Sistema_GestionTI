<?php
class ClientesController extends CrudController
{
    protected function cfg(): array
    {
        $rubros = ['Salud','Comercio','Educación','Servicios','Construcción','Turismo','Transporte','Retail','Industria','Tecnología','Gobierno','Otro'];
        $rubros = array_combine($rubros, $rubros);
        return [
            'slug' => 'clientes', 'table' => 'clientes', 'title' => 'Clientes', 'singular' => 'Cliente', 'group' => 'Clientes y Activos',
            'subtitle' => 'Empresas atendidas por el área de soporte técnico.', 'label_field' => 'razon_social', 'view' => true,
            'select' => "c.*, (SELECT COUNT(*) FROM tickets x WHERE x.cliente_id=c.id) AS n_tickets,
                         (SELECT COUNT(*) FROM activos a WHERE a.cliente_id=c.id) AS n_equipos,
                         (SELECT plan FROM contratos k WHERE k.cliente_id=c.id ORDER BY k.fecha_fin DESC LIMIT 1) AS plan",
            'from' => 'clientes c', 'order' => 'c.razon_social',
            'search' => ['c.razon_social', 'c.ruc', 'c.contacto', 'c.email'],
            'filters' => [
                ['name' => 'rubro', 'col' => 'c.rubro', 'label' => 'Rubro', 'options' => $rubros],
                ['name' => 'estado', 'col' => 'c.estado', 'label' => 'Estado', 'options' => ['1' => 'Activo', '0' => 'Inactivo']],
            ],
            'stats' => [
                ['Clientes registrados', 'SELECT COUNT(*) FROM clientes', 'bi-buildings-fill', '#4f46e5'],
                ['Clientes activos', 'SELECT COUNT(*) FROM clientes WHERE estado=1', 'bi-check-circle-fill', '#10b981'],
                ['Con contrato vigente', "SELECT COUNT(DISTINCT cliente_id) FROM contratos WHERE estado<>'vencido'", 'bi-file-earmark-check-fill', '#0ea5e9'],
                ['Equipos administrados', 'SELECT COUNT(*) FROM activos', 'bi-pc-display-horizontal', '#f59e0b'],
            ],
            'columns' => [
                ['label' => 'Cliente', 'key' => 'razon_social', 'sub' => 'ruc', 'main' => true],
                ['label' => 'Contacto', 'key' => 'contacto', 'sub' => 'telefono', 'main' => true],
                ['label' => 'Rubro', 'key' => 'rubro'],
                ['label' => 'Plan', 'html' => fn($r) => $r['plan'] ? pill($r['plan'], ['Premium' => 'soft-primary', 'Business' => 'soft-info', 'Básico' => 'muted'][$r['plan']]) : '<span class="text-muted small">Sin contrato</span>'],
                ['label' => 'Equipos', 'key' => 'n_equipos'],
                ['label' => 'Tickets', 'key' => 'n_tickets'],
                ['label' => 'Estado', 'html' => fn($r) => $r['estado'] ? pill('Activo', 'success') : pill('Inactivo', 'muted')],
            ],
            'fields' => [
                ['name' => 'razon_social', 'label' => 'Razón social', 'type' => 'text', 'required' => true, 'col' => 8, 'section' => 'Datos de la empresa', 'maxlength' => 150],
                ['name' => 'ruc', 'label' => 'RUC', 'type' => 'text', 'col' => 4, 'maxlength' => 15],
                ['name' => 'rubro', 'label' => 'Rubro', 'type' => 'select', 'options' => $rubros, 'col' => 4],
                ['name' => 'direccion', 'label' => 'Dirección', 'type' => 'text', 'col' => 8, 'maxlength' => 200],
                ['name' => 'contacto', 'label' => 'Persona de contacto', 'type' => 'text', 'col' => 4, 'section' => 'Contacto principal', 'maxlength' => 100],
                ['name' => 'telefono', 'label' => 'Teléfono', 'type' => 'text', 'col' => 4, 'maxlength' => 25],
                ['name' => 'email', 'label' => 'Correo electrónico', 'type' => 'email', 'col' => 4],
                ['name' => 'estado', 'label' => 'Cliente activo', 'type' => 'switch', 'col' => 12],
            ],
        ];
    }

    /** Ficha 360° del cliente */
    public function ver($id = 0): void
    {
        $this->guard();
        $db = Database::conn(); $id = (int)$id;
        $cli = $this->find($id);
        if (!$cli) { $this->flash('danger', 'El cliente no existe.'); $this->redirect('clientes'); }
        $q = fn($sql) => (function () use ($db, $sql, $id) { $s = $db->prepare($sql); $s->execute([$id]); return $s->fetchAll(); })();
        $this->render('clientes/ver', [
            'cli' => $cli,
            'contratos' => $q('SELECT * FROM contratos WHERE cliente_id=? ORDER BY fecha_fin DESC'),
            'activos' => $q('SELECT * FROM activos WHERE cliente_id=? ORDER BY codigo LIMIT 12'),
            'tickets' => $q("SELECT t.*, cat.nombre categoria FROM tickets t JOIN categorias cat ON cat.id=t.categoria_id WHERE t.cliente_id=? ORDER BY t.created_at DESC LIMIT 8"),
            'resumen' => $q("SELECT COUNT(*) total, SUM(estado IN ('abierto','en_proceso','pendiente')) abiertos, SUM(resuelto_at IS NOT NULL AND resuelto_at<=fecha_limite) en_sla, SUM(resuelto_at IS NOT NULL) resueltos FROM tickets WHERE cliente_id=?")[0],
        ], $cli['razon_social']);
    }
}
