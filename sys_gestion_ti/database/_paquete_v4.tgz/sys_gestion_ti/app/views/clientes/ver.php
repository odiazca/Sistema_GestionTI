<?php $sla = $resumen['resueltos'] ? round($resumen['en_sla'] * 100 / $resumen['resueltos']) : 100; ?>
<div class="page-head">
  <div>
    <div class="crumbs"><a href="<?= url('dashboard') ?>">Inicio</a> / <a href="<?= url('clientes') ?>">Clientes</a> / Ficha</div>
    <div class="detail-hero">
      <div class="logo"><?= e(iniciales($cli['razon_social'])) ?></div>
      <div>
        <h1 class="m-0" style="font-size:1.5rem;font-weight:800"><?= e($cli['razon_social']) ?></h1>
        <p class="m-0 text-muted"><?= e($cli['rubro'] ?: 'Sin rubro') ?> · RUC <?= e($cli['ruc'] ?: '—') ?> · <?= $cli['estado'] ? pill('Activo', 'success') : pill('Inactivo', 'muted') ?></p>
      </div>
    </div>
  </div>
  <div class="d-flex gap-2">
    <a href="<?= url('clientes/editar/' . $cli['id']) ?>" class="btn btn-ghost"><i class="bi bi-pencil me-1"></i>Editar</a>
    <a href="<?= url('tickets/crear?cliente=' . $cli['id']) ?>" class="btn btn-brand"><i class="bi bi-plus-lg me-1"></i>Nuevo ticket</a>
  </div>
</div>

<div class="row g-3 mb-3">
  <div class="col-6 col-xl-3"><div class="stat-mini"><span class="ic" style="background:#4f46e51f;color:#4f46e5"><i class="bi bi-ticket-perforated-fill"></i></span><div><b><?= (int)$resumen['total'] ?></b><span>Tickets totales</span></div></div></div>
  <div class="col-6 col-xl-3"><div class="stat-mini"><span class="ic" style="background:#f59e0b1f;color:#f59e0b"><i class="bi bi-hourglass-split"></i></span><div><b><?= (int)$resumen['abiertos'] ?></b><span>Abiertos</span></div></div></div>
  <div class="col-6 col-xl-3"><div class="stat-mini"><span class="ic" style="background:#10b9811f;color:#10b981"><i class="bi bi-shield-check"></i></span><div><b><?= $sla ?>%</b><span>Cumplimiento SLA</span></div></div></div>
  <div class="col-6 col-xl-3"><div class="stat-mini"><span class="ic" style="background:#0ea5e91f;color:#0ea5e9"><i class="bi bi-pc-display-horizontal"></i></span><div><b><?= count($activos) ?><?= count($activos) >= 12 ? '+' : '' ?></b><span>Equipos</span></div></div></div>
</div>

<div class="row g-3">
  <div class="col-xl-4">
    <div class="card-ui h-100">
      <div class="card-head"><div><h6>Información de contacto</h6></div></div>
      <div class="info-list">
        <div class="info-item"><span>Contacto</span><b><?= e($cli['contacto'] ?: '—') ?></b></div>
        <div class="info-item"><span>Teléfono</span><b><?= e($cli['telefono'] ?: '—') ?></b></div>
        <div class="info-item"><span>Correo</span><b><?= e($cli['email'] ?: '—') ?></b></div>
        <div class="info-item"><span>Dirección</span><b><?= e($cli['direccion'] ?: '—') ?></b></div>
        <div class="info-item"><span>Cliente desde</span><b><?= fdate($cli['created_at']) ?></b></div>
      </div>
      <h6 class="mini-title mt-4">Contratos</h6>
      <?php foreach ($contratos as $k): ?>
        <div class="alert-row"><div><b><?= e($k['codigo']) ?> · <?= e($k['plan']) ?></b><small>Hasta <?= fdate($k['fecha_fin']) ?> · SLA <?= (int)$k['sla_respuesta_horas'] ?>h/<?= (int)$k['sla_resolucion_horas'] ?>h</small></div>
          <?= $k['estado'] === 'vencido' ? pill('Vencido', 'danger') : ($k['estado'] === 'por_vencer' ? pill('Por vencer', 'warning') : pill('Vigente', 'success')) ?></div>
      <?php endforeach; if (!$contratos) echo '<p class="text-muted small">Sin contratos registrados.</p>'; ?>
    </div>
  </div>
  <div class="col-xl-8">
    <div class="card-ui mb-3">
      <div class="card-head"><div><h6>Últimos tickets</h6></div><a href="<?= url('tickets?cliente=' . $cli['id']) ?>" class="btn btn-soft btn-sm">Ver todos</a></div>
      <div class="table-responsive"><table class="table-ui">
        <thead><tr><th>Ticket</th><th>Categoría</th><th>Prioridad</th><th>Estado</th><th>Fecha</th></tr></thead>
        <tbody>
        <?php foreach ($tickets as $t): ?>
          <tr><td><a href="<?= url('tickets/ver/' . $t['id']) ?>" class="tk-code fw-bold"><?= e($t['codigo']) ?></a><div class="tk-sub"><?= e(mb_strimwidth($t['asunto'], 0, 44, '…')) ?></div></td>
              <td><?= e($t['categoria']) ?></td><td><?= prio_pill($t['prioridad']) ?></td><td><?= estado_pill($t['estado']) ?></td><td class="small"><?= fdate($t['created_at']) ?></td></tr>
        <?php endforeach; if (!$tickets): ?><tr><td colspan="5" class="empty-row">Sin tickets aún.</td></tr><?php endif; ?>
        </tbody></table></div>
    </div>
    <div class="card-ui">
      <div class="card-head"><div><h6>Equipos del cliente</h6></div><a href="<?= url('activos?cliente=' . $cli['id']) ?>" class="btn btn-soft btn-sm">Ver inventario</a></div>
      <div class="row g-2">
        <?php foreach ($activos as $a): ?>
        <div class="col-md-6"><div class="alert-row" style="border:1px solid var(--line);border-radius:12px;padding:.65rem .85rem">
          <div><b><?= e($a['tipo']) ?> <?= e($a['marca']) ?></b><small><?= e($a['codigo']) ?> · <?= e($a['ubicacion'] ?: '—') ?></small></div>
          <?= $a['estado'] === 'operativo' ? pill('OK', 'success') : pill('Rep.', 'warning') ?></div></div>
        <?php endforeach; if (!$activos) echo '<p class="text-muted small m-0">Sin equipos registrados.</p>'; ?>
      </div>
    </div>
  </div>
</div>
