<?php
class DashboardController extends Controller
{
    public function index(): void
    {
        $this->requireAuth();
        $m = $this->model('Dashboard');
        $data = [
            'kpi'       => $m->kpis(),
            'serie'     => $m->serieMensual(),
            'estados'   => $m->porEstado(),
            'categorias'=> $m->porCategoria(),
            'prioridad' => $m->porPrioridad(),
            'tecnicos'  => $m->cargaTecnicos(),
            'recientes' => $m->recientes(),
            'actividad' => $m->actividad(),
            'alertas'   => $m->alertas(),
            'canales'   => $m->canales(),
            'spark'     => $m->sparkline(),
        ];
        $this->render('dashboard/index', $data, 'Dashboard');
    }
}
