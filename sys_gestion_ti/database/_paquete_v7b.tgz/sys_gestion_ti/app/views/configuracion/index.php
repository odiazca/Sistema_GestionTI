<div class="page-head">
  <div>
    <div class="crumbs"><a href="<?= url('dashboard') ?>">Inicio</a> / Sistema</div>
    <h1>Configuración</h1>
    <p>Parámetros generales de la empresa y del sistema.</p>
  </div>
</div>
<div class="row g-3">
  <div class="col-lg-3">
    <div class="card-ui p-2">
      <?php foreach ($tabs as $k => [$lab, $ic]): ?>
        <a href="<?= url('configuracion?tab=' . $k) ?>" class="cfg-tab <?= $tab === $k ? 'active' : '' ?>"><i class="bi <?= $ic ?>"></i><?= e($lab) ?></a>
      <?php endforeach; ?>
    </div>
  </div>
  <div class="col-lg-9">

  <?php if ($tab === 'empresa'): ?>
    <form method="post" action="<?= url('configuracion/guardar') ?>" class="card-ui form-ui">
      <?= csrf_field() ?><input type="hidden" name="tab" value="empresa">
      <div class="card-head"><div><h6>Datos de la empresa</h6><small>Se muestran en reportes e impresiones</small></div></div>
      <div class="row g-3">
        <div class="col-md-8"><label class="lbl">Razón social / nombre comercial</label><input class="form-control" name="empresa_nombre" value="<?= e(cfg('empresa_nombre', APP_NAME)) ?>"></div>
        <div class="col-md-4"><label class="lbl">RUC</label><input class="form-control" name="empresa_ruc" value="<?= e(cfg('empresa_ruc')) ?>" maxlength="15"></div>
        <div class="col-md-8"><label class="lbl">Dirección</label><input class="form-control" name="empresa_direccion" value="<?= e(cfg('empresa_direccion')) ?>"></div>
        <div class="col-md-4"><label class="lbl">Teléfono</label><input class="form-control" name="empresa_telefono" value="<?= e(cfg('empresa_telefono')) ?>"></div>
        <div class="col-md-6"><label class="lbl">Correo de soporte</label><input type="email" class="form-control" name="empresa_email" value="<?= e(cfg('empresa_email')) ?>"></div>
      </div>
      <div class="text-end mt-4"><button class="btn btn-brand px-4"><i class="bi bi-check2-circle me-1"></i>Guardar cambios</button></div>
    </form>

  <?php elseif ($tab === 'operacion'): ?>
    <form method="post" action="<?= url('configuracion/guardar') ?>" class="card-ui form-ui">
      <?= csrf_field() ?><input type="hidden" name="tab" value="operacion">
      <div class="card-head"><div><h6>Operación y facturación</h6><small>Valores por defecto al registrar órdenes y cotizaciones</small></div></div>
      <div class="row g-3">
        <div class="col-md-4"><label class="lbl">Tarifa por hora técnica (S/)</label><input type="number" step="0.01" min="0" class="form-control" name="tarifa_hora" value="<?= e(cfg('tarifa_hora', 45)) ?>"><div class="help">Se propone en cada nueva orden de servicio.</div></div>
        <div class="col-md-4"><label class="lbl">IGV (%)</label><input type="number" step="0.01" min="0" class="form-control" name="igv" value="<?= e(cfg('igv', 18)) ?>"></div>
        <div class="col-md-12"><label class="lbl">Horario de atención</label><input class="form-control" name="horario_atencion" value="<?= e(cfg('horario_atencion', 'Lunes a viernes de 8:00 a 18:00')) ?>"></div>
      </div>
      <div class="text-end mt-4"><button class="btn btn-brand px-4"><i class="bi bi-check2-circle me-1"></i>Guardar cambios</button></div>
    </form>
    <div class="card-ui mt-3">
      <div class="card-head"><div><h6>Plazos de SLA por prioridad</h6><small>Se aplican sobre las horas de resolución del contrato del cliente</small></div></div>
      <div class="row g-3 text-center">
        <?php foreach (['critica' => ['Crítica', '25 %', '#ef4444'], 'alta' => ['Alta', '50 %', '#f59e0b'], 'media' => ['Media', '100 %', '#0ea5e9'], 'baja' => ['Baja', '150 %', '#94a3b8']] as [$l, $p, $c]): ?>
        <div class="col-6 col-md-3"><div class="stat-mini justify-content-center flex-column gap-0 py-3"><b style="color:<?= $c ?>"><?= $p ?></b><span><?= $l ?></span></div></div>
        <?php endforeach; ?>
      </div>
      <p class="text-muted small mt-3 mb-0">Ejemplo: contrato Premium (24 h) → ticket crítico se debe resolver en 6 h. Los plazos base se definen en cada contrato.</p>
    </div>

  <?php elseif ($tab === 'categorias'): ?>
    <div class="card-ui mb-3 form-ui">
      <div class="card-head"><div><h6>Nueva categoría de tickets</h6></div></div>
      <form method="post" action="<?= url('configuracion/categoria') ?>" class="row g-2 align-items-end">
        <?= csrf_field() ?>
        <div class="col-md-5"><label class="lbl">Nombre</label><input class="form-control" name="nombre" maxlength="60" required></div>
        <div class="col-md-4"><label class="lbl">Ícono</label><select class="form-select" name="icono"><?php foreach ($iconos as $k => $v): ?><option value="<?= $k ?>"><?= e($v) ?></option><?php endforeach; ?></select></div>
        <div class="col-md-1"><label class="lbl">Color</label><input type="color" class="form-control form-control-color w-100" style="height:44px;padding:4px" name="color" value="#4f46e5"></div>
        <div class="col-md-2"><button class="btn btn-brand w-100" style="height:44px"><i class="bi bi-plus-lg"></i> Agregar</button></div>
      </form>
    </div>
    <div class="card-ui">
      <div class="card-head"><div><h6>Categorías (<?= count($cats) ?>)</h6></div></div>
      <?php foreach ($cats as $c): ?>
      <form method="post" action="<?= url('configuracion/categoria') ?>" class="cat-row form-ui">
        <?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>">
        <span class="tl-ic" style="background:<?= e($c['color']) ?>22;color:<?= e($c['color']) ?>"><i class="bi <?= e($c['icono']) ?>"></i></span>
        <input class="form-control" name="nombre" value="<?= e($c['nombre']) ?>" maxlength="60" style="flex:1;min-width:150px">
        <select class="form-select" name="icono" style="width:190px"><?php foreach ($iconos as $k => $v): ?><option value="<?= $k ?>" <?= $c['icono'] === $k ? 'selected' : '' ?>><?= e($v) ?></option><?php endforeach; ?></select>
        <input type="color" class="form-control form-control-color" style="width:52px;height:44px;padding:4px" name="color" value="<?= e($c['color']) ?>">
        <span class="text-muted small" style="width:80px"><?= (int)$c['usos'] ?> tickets</span>
        <button class="act-btn" title="Guardar"><i class="bi bi-check2"></i></button>
        <button type="submit" formaction="<?= url('configuracion/categoria_eliminar/' . $c['id']) ?>" class="act-btn danger" title="Eliminar"><i class="bi bi-trash3"></i></button>
      </form>
      <?php endforeach; ?>
    </div>

  <?php elseif ($tab === 'seguridad'): ?>
    <form method="post" action="<?= url('configuracion/password') ?>" class="card-ui form-ui" style="max-width:560px">
      <?= csrf_field() ?>
      <div class="card-head"><div><h6>Cambiar mi contraseña</h6><small>Usa al menos 6 caracteres</small></div></div>
      <div class="mb-3"><label class="lbl">Contraseña actual</label><input type="password" class="form-control" name="actual" autocomplete="current-password" required></div>
      <div class="mb-3"><label class="lbl">Nueva contraseña</label><input type="password" class="form-control" name="nueva" autocomplete="new-password" required></div>
      <div class="mb-3"><label class="lbl">Confirmar nueva contraseña</label><input type="password" class="form-control" name="confirmar" autocomplete="new-password" required></div>
      <button class="btn btn-brand"><i class="bi bi-key me-1"></i>Actualizar contraseña</button>
    </form>

  <?php else: ?>
    <div class="card-ui mb-3">
      <div class="card-head"><div><h6>Copia de seguridad</h6><small>Descarga un archivo .sql con todos los datos del sistema</small></div></div>
      <form method="post" action="<?= url('configuracion/respaldo') ?>" class="d-flex align-items-center gap-3 flex-wrap">
        <?= csrf_field() ?>
        <div class="empty-icon m-0" style="width:56px;height:56px;font-size:1.5rem;border-radius:16px"><i class="bi bi-cloud-arrow-down"></i></div>
        <div class="flex-grow-1"><b>Respaldo completo de la base de datos</b><div class="text-muted small">Se puede restaurar importando el archivo en MySQL (phpMyAdmin o HeidiSQL). Recomendado: semanal.</div></div>
        <button class="btn btn-brand"><i class="bi bi-download me-1"></i>Descargar respaldo</button>
      </form>
    </div>
    <div class="row g-3">
      <div class="col-md-6"><div class="card-ui h-100"><div class="card-head"><div><h6>Entorno</h6></div></div>
        <div class="info-list"><?php foreach ($info as $k => $v): ?><div class="info-item"><span><?= e($k) ?></span><b><?= e($v) ?></b></div><?php endforeach; ?></div></div></div>
      <div class="col-md-6"><div class="card-ui h-100"><div class="card-head"><div><h6>Registros</h6></div></div>
        <div class="info-list"><?php foreach ($conteos as $k => $v): ?><div class="info-item"><span><?= e(ucwords(str_replace('_', ' ', $k))) ?></span><b><?= e($v) ?></b></div><?php endforeach; ?></div></div></div>
    </div>
  <?php endif; ?>

  </div>
</div>
